import React from "react";

function NoteFooter() {
  return (
    <div className="note-app__footer">
      <p>Copyright &#169; 2024 - Husni Mubarok</p>
    </div>
  );
}

export default NoteFooter;
